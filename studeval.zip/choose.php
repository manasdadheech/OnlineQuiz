<?php
$title='Login - Online examination system';
require('./template/header.php');

echo '<div class="info">Which Question type do you wish to attempt: <a href="./exam.php">Multiple choice Questions</a>&nbsp
<a href="./examS.php">Subjective Qustions</a>.</div>';
require('./template/footer.php');
?>
