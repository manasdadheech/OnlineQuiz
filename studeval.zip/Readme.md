## Readme

This is a proof-of-concept micro-project to demonstrate the feasibility of creating an _Online Examination System_ using the PHP/MySQL stack.

Contributions by :
* Debjyoti Saha
* Saumya Majumder
* Soumik Ghosh
