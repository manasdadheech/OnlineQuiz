<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="./style.css" />
		<script type="text/javascript" src="./js/validate.js"></script>
		<title><?php echo $title; ?></title>
	</head>
	<body>
    <div class="wrapper">
    <img src="./images/logo.png" alt="logo" class="logo" />
